<!--
=====================================================================
PASTE THE 8 GOLDEN RULES FROM THE COURSE TEMPLATE HERE, ABOVE THIS LINE.
Copy them from the official FIN506 template in Blackboard EXACTLY as written.
Do NOT modify, reword, translate or reorder them.
The Puente-specific rules below stay underneath.
=====================================================================
-->

# Puente — Project-specific rules for AI agents

These rules apply in addition to (never instead of) the 8 golden rules pasted above.

## 1. Vertical
Crypto & Stablecoins: instant USDC remittances and gig-pay advances for DiDi/Rappi workers in Mexico City. Do not drift into other verticals (lending, cards, investing).

## 2. Single flow
Only the 5-step core flow in `SPEC.md` (sign-in → receive remittance → gig pay advance → use funds by QR or SPEI → instant 1:1 balance and private history). Scope was frozen on Oct 22, 2026. Do not add features or screens outside it.

## 3. Stack
Next.js (App Router), React, Tailwind CSS, Prisma (SQLite in dev), `bcryptjs`, `jose`, `zod`, `lucide-react`. Use only the closed package list in `SPEC.md`; adding a package requires a changelog entry in `SPEC.md` and a line in `DECISIONS.md`.

## 4. Out of scope
No physical card, no staking/yield, no credit/loans, no real blockchain/bank/KYC/payroll integrations.

## 5. Data and money rules
- All data is **fictional**. Never use real people, real accounts, real CLABEs or real money.
- Every external rail must stay simulated and labeled `(Simulated)` in the UI; the permanent banner "SIMULATED ENVIRONMENT / TESTNET — Fictional data, no real money" must never be removed.
- Money is stored as integers in minor units. Single currency for reports: MXN (1 USD = 20.00 MXN, assumption).
- No secrets, API keys or real credentials in the repo. Use `.env` (git-ignored) and keep `.env.example` current.

## 6. Security rules
- User id comes only from the signed session cookie, never from URLs, query strings or request bodies.
- No personal data (names, emails, account numbers) in URLs or logs. Store only masked CLABEs.
- Every query on user-owned tables must be scoped by the session user id.

## 7. `TODO-verify` rule
Any figure, deadline or legal/regulatory requirement that has not been confirmed from an official source must be written literally as `TODO-verify` next to the claim. Never present an unconfirmed number as fact.

## 8. Ownership
Owner and responsible author: Alejandra Jalife (ID 0271100). AI-generated content must be reviewed and validated by the owner before submission; log AI usage in `BITACORA.md`.
