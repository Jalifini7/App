# PROJECT_METHOD.md

**Reminder: this file must be copied WITHOUT CHANGES from the official course template in Blackboard (FIN506 Financial Technology).**

Replace the entire contents of this file with the template's `PROJECT_METHOD.md`, exactly as provided. Do not edit, reword, translate or reformat it. Delete this reminder text when you paste it.
