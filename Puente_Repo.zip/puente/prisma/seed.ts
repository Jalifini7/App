// Seed: 100% FICTIONAL data. Two test accounts to demonstrate per-user data isolation.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// Demo passwords (fictional accounts only). Override with SEED_PASSWORD_* in .env.
const PASSWORD_MARIANA = process.env.SEED_PASSWORD_MARIANA || "PuenteDemo-Mariana-2026";
const PASSWORD_CARLOS = process.env.SEED_PASSWORD_CARLOS || "PuenteDemo-Carlos-2026";

async function main() {
  // Clean slate so the seed is idempotent.
  await prisma.outgoingTransaction.deleteMany();
  await prisma.incomingTransaction.deleteMany();
  await prisma.balance.deleteMany();
  await prisma.affiliatedMerchant.deleteMany();
  await prisma.user.deleteMany();

  const mariana = await prisma.user.create({
    data: {
      email: "mariana.torres@puente.test",
      name: "Mariana Torres",
      passwordHash: await bcrypt.hash(PASSWORD_MARIANA, 12),
      balance: { create: { usdcCents: 0 } },
    },
  });

  const carlos = await prisma.user.create({
    data: {
      email: "carlos.mendoza@puente.test",
      name: "Carlos Mendoza",
      passwordHash: await bcrypt.hash(PASSWORD_CARLOS, 12),
      balance: { create: { usdcCents: 32505 } }, // 325.05 USDC (fictional), matches his seeded remittance
    },
  });

  // Carlos gets a pre-existing private history, so isolation is visible from minute one.
  await prisma.incomingTransaction.create({
    data: {
      userId: carlos.id,
      kind: "REMITTANCE",
      counterparty: "Brother (Houston) - fictional",
      sourceCurrency: "USD",
      sourceAmountMinor: 33000,
      fxRateMxnPerUsd: 20,
      grossUsdcCents: 33000,
      spreadBps: 150,
      feeUsdcCents: 495,
      netUsdcCents: 32505,
      rail: "On-Ramp USD->USDC (Simulated) / Solana USDC-SPL (Simulated)",
    },
  });

  await prisma.affiliatedMerchant.createMany({
    data: [
      { name: "Tienda Don Pepe (fictional)", category: "Grocery", qrCode: "PUENTE-QR-0001" },
      { name: "Taqueria El Sur (fictional)", category: "Food", qrCode: "PUENTE-QR-0002" },
      { name: "Farmacia La Esquina (fictional)", category: "Pharmacy", qrCode: "PUENTE-QR-0003" },
      { name: "Gasolinera Tlalpan (fictional)", category: "Fuel", qrCode: "PUENTE-QR-0004" },
    ],
  });

  console.log("Seed complete (fictional data only).");
  console.log(`  User 1: ${mariana.email}`);
  console.log(`  User 2: ${carlos.email}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
