# Puente

> Instant USDC remittances and gig-pay advances for DiDi and Rappi workers in Mexico City.
> **SIMULATED ENVIRONMENT / TESTNET — Fictional data, no real money.**

- **Owner:** Alejandra Jalife (ID 0271100)
- **Course:** FIN506 Financial Technology, Universidad Panamericana — Final Project
- **Vertical:** Crypto & Stablecoins
- **Stack:** Next.js (App Router), React, Tailwind CSS, Prisma + SQLite, `bcryptjs`, `jose`, `zod`

## The problem

Drivers and delivery couriers on DiDi and Rappi in Mexico City lose **6%–8%** of the value of each remittance from the US and wait **2–4 days** for it to settle (sending fees, FX spread, bank settlement). Puente converts the remittance to USDC at a **1.5%** spread and advances weekly gig pay at a **0.5%** spread, with instant settlement.

Archetype user (pseudonym): **Mariana Torres**, 27, DiDi driver and Rappi courier in southern CDMX.

## Core flow (5 steps, scope frozen)

1. **Secure sign-in** — per-user data isolation; no personal data in URLs or logs.
2. **Receive a US remittance** — USD → USDC (simulated Solana USDC-SPL), 1.5% spread.
3. **Gig pay advance** — DiDi/Rappi weekly payout into the Puente wallet (simulated), 0.5% spread.
4. **Use funds** — (a) pay an affiliated merchant by QR, or (b) withdraw MXN via SPEI (simulated).
5. **Instant 1:1 balance update** and private transaction history.

## Requirements

- Node.js 18.18+ (20 LTS recommended) and npm
- Nothing else. SQLite runs as a local file.

## Quick start (local)

```bash
# 1. Install dependencies
npm install

# 2. Create your environment file
cp .env.example .env
#    Open .env and set SESSION_SECRET to a random string of 32+ characters:
#    openssl rand -base64 48

# 3. Create the database and load fictional seed data
npm run setup        # = prisma generate + prisma db push + prisma db seed

# 4. Run the app
npm run dev          # http://localhost:3000
```

To reset the demo data at any time: `npm run db:seed` (the seed is idempotent and wipes/recreates all rows).

## Test accounts (fictional)

The exact credentials are in the separate credentials note delivered with this project (for Blackboard). Defaults used by the seed when `SEED_PASSWORD_*` is empty:

| User | Email | Password |
|------|-------|----------|
| 1 — Mariana Torres | `mariana.torres@puente.test` | `PuenteDemo-Mariana-2026` |
| 2 — Carlos Mendoza | `carlos.mendoza@puente.test` | `PuenteDemo-Carlos-2026` |

Test CLABE for the SPEI withdrawal (valid check digit, fictional): `012180001234567899`.

## Live demo walkthrough (≤ 3 minutes)

1. Sign in as Mariana (balance starts at 0.00 USDC, empty history).
2. **Step 2:** send a USD 200 remittance → you receive 197.00 USDC (1.5% spread = 3.00 USDC).
3. **Step 3:** simulate a DiDi payout of MXN 1,800 → 90.00 USDC gross, 89.55 USDC net (0.5% spread).
4. **Step 4a:** pay "Tienda Don Pepe" 10 USDC by QR. **Step 4b:** withdraw 50 USDC via SPEI to the test CLABE (= MXN 1,000.00).
5. **Step 5:** balance and history update immediately (balance = 197.00 + 89.55 − 10.00 − 50.00 = 226.55 USDC).

## Test per-user data isolation

1. Sign in as **Mariana**, make a remittance. Sign out.
2. Sign in as **Carlos**: his balance (325.05 USDC) and his own seeded history appear — **none** of Mariana's transactions.
3. While signed in as Carlos, open `http://localhost:3000/api/transactions?userId=<any id>` — the query parameter is **ignored**; the response only contains Carlos's data, because the user id is read exclusively from the signed, `httpOnly` session cookie.
4. Signed out, open `/dashboard` or `/api/transactions` → redirect to `/login` / `401`.
5. No URL in the app ever contains a user id, email or account number, and the server never logs personal data.

## Deploy

### Option A — Vercel (recommended for a public demo)

Vercel's filesystem is ephemeral, so **SQLite will not persist there**. Use a hosted PostgreSQL (e.g. Neon or Vercel Postgres):

1. In `prisma/schema.prisma` change `provider = "sqlite"` to `provider = "postgresql"`.
2. Push the repo to GitHub and import it in Vercel.
3. Set environment variables in Vercel: `DATABASE_URL` (the Postgres connection string) and `SESSION_SECRET` (32+ random chars).
4. From your machine, once: `DATABASE_URL="<postgres url>" npx prisma db push && DATABASE_URL="<postgres url>" npx prisma db seed`.
5. Deploy. The build script already runs `prisma generate`.

### Option B — Any Node host / VPS

```bash
npm install && npm run setup && npm run build && npm start
```

Set `SESSION_SECRET` and `DATABASE_URL` in the host environment.

## Simulated services (explicit list)

Everything external is **simulated** and labeled `(Simulated)` in the UI. No real money, tokens, banks or identity documents are involved.

| Rail / service | Status |
|---|---|
| On-Ramp USD → USDC | Simulated |
| Solana USDC-SPL | Simulated (no blockchain connection) |
| Gig-Payroll (DiDi / Rappi payouts) | Simulated |
| KYC / identity verification | Simulated |
| Merchant QR payments | Simulated |
| SPEI MXN withdrawal | Simulated |
| FX rate | Fixed assumption: 1 USD = 20.00 MXN |

## Security notes

- Passwords hashed with `bcryptjs` (cost 12). Sessions are signed JWTs (`jose`, HS256, 2 h) in an `httpOnly`, `sameSite=lax` cookie (`secure` in production).
- All inputs validated with `zod`. Balance debits are atomic (no overdraft, no double spend).
- Only the masked CLABE (`****1234`) is stored. Generic login errors, throttling per IP, security headers, `Cache-Control: no-store`.
- No secrets in the repo: use `.env` (git-ignored) based on `.env.example`.

## Regulatory note

Puente custodies customer funds (USDC 1:1), does not lend them and pays no yield. The target legal figure is an IFPE under the Fintech Law; the MVP would first operate through a licensed partner. See `SPEC.md` and `DECISIONS.md`. Any unconfirmed legal figure is marked `TODO-verify`.

## Repository files

`README.md` · `SPEC.md` · `DECISIONS.md` · `AGENTS.md` · `BITACORA.md` · `PROJECT_METHOD.md`
