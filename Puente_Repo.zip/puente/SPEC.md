# SPEC — Puente

- **Owner:** Alejandra Jalife (ID 0271100)
- **Date:** November 16, 2026
- **Course:** FIN506 Financial Technology, Universidad Panamericana
- **Vertical:** Crypto & Stablecoins
- **Environment:** SIMULATED / TESTNET — fictional data, no real money

## 1. Problem

Drivers (DiDi) and couriers (Rappi) in Mexico City lose between 6% and 8% of the value of each remittance received from the US and wait 2 to 4 days for settlement, because of sending fees, FX spread and bank settlement times. *(Source: assumption — founder estimate; interview evidence to be cited in BITACORA.md, `TODO-verify`.)*

## 2. Specific user

**Mariana Torres** (pseudonym), 27, DiDi driver and Rappi courier in southern CDMX. Receives USD 150–250 per month from her sister in Dallas and weekly payouts from the gig platforms.

## 3. Core flow (5 steps — scope frozen at Avance 2, Oct 22, 2026)

1. **Secure sign-in:** strict per-user isolation (User A can never see or query User B's data); no personal data in URLs or logs.
2. **Receive US remittance:** sender pays USD → Puente converts to USDC (Solana USDC-SPL rail, simulated), 1.5% spread, credits wallet.
3. **Gig pay advance:** DiDi/Rappi weekly payout deposited into the Puente wallet (simulated), 0.5% spread.
4. **Use funds:** (a) pay an affiliated merchant by QR, or (b) withdraw MXN to a bank account via SPEI (simulated).
5. **Instant 1:1 balance update** of the USDC balance and the private transaction history.

## 4. Data model

| Model | Purpose | Key fields |
|---|---|---|
| `User` | Account owner | `id`, `email` (unique), `name`, `passwordHash` |
| `Balance` | USDC balance, one per user | `userId` (unique), `usdcCents` |
| `IncomingTransaction` | Remittances and gig payouts | `userId`, `kind` (REMITTANCE / GIG_PAYROLL), `sourceCurrency`, `sourceAmountMinor`, `fxRateMxnPerUsd`, `grossUsdcCents`, `spreadBps`, `feeUsdcCents`, `netUsdcCents`, `rail` |
| `OutgoingTransaction` | Merchant payments and SPEI withdrawals | `userId`, `kind` (QR_MERCHANT / SPEI_WITHDRAWAL), `usdcCents`, `mxnCents`, `merchantId?`, `destinationMasked?`, `status`, `rail` |
| `AffiliatedMerchant` | Merchants payable by QR | `name`, `category`, `qrCode` (unique), `active` |

Amounts are integers in minor units (1 USDC = 100 units; 1 MXN = 100 centavos). Every user-owned table is queried only with the `userId` from the signed session.

## 5. Closed list of software packages

Runtime/product packages (nothing else may be added without a changelog entry):

`next`, `react`, `react-dom`, `tailwindcss`, `prisma`, `@prisma/client`, `bcryptjs`, `jose`, `zod`, `lucide-react`

*Build-toolchain only (type definitions and compilers, not product dependencies): `typescript`, `tsx`, `postcss`, `autoprefixer`, `@types/node`, `@types/react`, `@types/react-dom`, `@types/bcryptjs`.*

Banks, on/off-ramp providers, KYC vendors and platforms are **business partners, not software dependencies**, and are intentionally not listed here.

## 6. Out of Scope

- No physical card.
- No staking or yield of any kind.
- No credit or loans.
- No real blockchain, bank, KYC or payroll integrations (all simulated).
- No multi-currency beyond USD/USDC ↔ MXN; no multi-country.

## 7. Unit economics (currency: MXN; fixed FX 1 USD = 20.00 MXN, assumption)

Period: monthly per active user, steady state. Source for every row: **assumption** (founder model; to be replaced by measured data after pilot).

| Metric | Value | Basis |
|---|---|---|
| ARPU | MXN 85 / month | 1.5% spread on ~USD 200 of remittances + 0.5% spread on gig advances — assumption |
| Gross margin | 70% | Low Solana network fees; direct costs: on/off-ramp, KYC, custody, liquidity, compliance — assumption |
| Contribution per month | MXN 59.50 | 85 × 70% |
| Monthly churn | 8% | Gig income volatility — assumption |
| Average customer life | 12.5 months | 1 / 0.08 |
| CAC | MXN 150 | WhatsApp driver-group referrals + light social ads — assumption |
| LTV | ≈ MXN 744 | 59.50 × 12.5 = 743.75 |
| LTV / CAC | ≈ 5.0x | 743.75 / 150 = 4.96 |
| Payback | ≈ 2.5 months | 150 / 59.50 = 2.52 |
| Spread — remittances | 1.5% | assumption |
| Spread — gig payroll | 0.5% | assumption |
| Spread — blended | ~1.0% | assumption |
| Volume per user per month | MXN 10,600 (~USD 530) | remittance + payroll — assumption |
| Target active users, month 6 | 500 | assumption |
| **Deciding number** | **Spread × Volume** | driven mainly by growth of active users |

`TODO-verify`: reconcile ARPU (MXN 85) with blended spread × volume (≈1.0% × MXN 10,600 = MXN 106) in the financial model — the gap implies the 1.0% blended spread is not applied to all volume (e.g., partial payroll adoption). Document the chosen reconciliation before the Excel is final.

## 8. Regulatory summary

1. Holds customer money? **Yes** — USDC 1:1 in segregated liquid reserves between arrival and withdrawal/spend.
2. Lends it? **No.**
3. Pays yield/interest? **No** (that would require a banking or SOFIPO license).

Target figure: **IFPE** under the Fintech Law. Route: operate first through a licensed partner while pursuing own license (capital ~MXN 5M–14M `TODO-verify`; authorization 12–18 months with CNBV/Banxico `TODO-verify`; segregated account/trust at a custodian bank). Supervisors: CNBV, Banxico, CONDUSEF; AML/KYC from day 1.

## 9. Changelog

| Date | Change | By |
|---|---|---|
| 2026-08 | First draft: problem, user, regulatory route, unit economics | Alejandra Jalife |
| 2026-09 | Updated after user validation | Alejandra Jalife |
| 2026-10-22 | Scope frozen (Avance 2): 5-step core flow, Out of Scope list | Alejandra Jalife |
| 2026-11-16 | MVP closed; financial model and pitch aligned; spec finalized | Alejandra Jalife |
