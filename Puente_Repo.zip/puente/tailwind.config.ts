import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        puente: { 50: "#eefbf4", 500: "#10b981", 600: "#059669", 700: "#047857", 900: "#064e3b" },
      },
    },
  },
  plugins: [],
};

export default config;
