# DECISIONS — Puente

One line per decision that is costly to reverse. Owner: Alejandra Jalife.

| # | Decision | Why |
|---|---|---|
| 1 | **Stack: Next.js (App Router) + React + Tailwind + Prisma + SQLite** (PostgreSQL for hosted deploys) | One codebase for UI and API, fastest path to a working, demoable MVP by a solo founder; Prisma makes a later move to PostgreSQL a one-line provider change. |
| 2 | **Auth: `bcryptjs` + signed JWT session in an `httpOnly` cookie (`jose`)** | Server-side identity means the user id never appears in URLs/bodies, which is the foundation of per-user data isolation. |
| 3 | **Legal figure: IFPE (electronic payment funds institution) under the Fintech Law** | Puente holds customer funds but does not lend or pay yield, which fits an IFPE; a bank/SOFIPO license is unnecessary and far costlier. |
| 4 | **Route: launch through a licensed partner first, pursue own IFPE license in parallel** | Own license needs ~MXN 5M–14M capital and 12–18 months `TODO-verify`; a partner lets us test the market without waiting. |
| 5 | **Rail: Solana USDC-SPL (simulated in the MVP)** | Very low network fees protect the 70% gross margin and give near-instant settlement vs. 2–4 days. |
| 6 | **Spreads: 1.5% on remittances, 0.5% on gig-payroll advances** | Well below the 6%–8% users lose today, yet enough to fund a 70% gross margin; the lower payroll spread reflects lower FX/liquidity risk. |
| 7 | **Monthly churn assumption: 8%** | Gig income is volatile; 8% gives a conservative 12.5-month life, so LTV/CAC (~5.0x) is not inflated by optimistic retention. |
| 8 | **Single reporting currency: MXN (fixed 1 USD = 20.00 MXN)** | Users earn, spend and withdraw in pesos; one currency keeps the Excel and the deck consistent and auditable. |
| 9 | **Integer minor units for all money (cents / centavos)** | Avoids floating-point errors in a financial ledger; mistakes here are expensive to fix after data exists. |
| 10 | **Fixed 5-step core flow, frozen at Avance 2 (Oct 22, 2026)** | Prevents scope creep; everything else is in `Out of Scope` in `SPEC.md`. |
