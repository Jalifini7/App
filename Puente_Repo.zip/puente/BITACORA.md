# BITACORA — Puente

**Owner of this log:** Alejandra Jalife (ID 0271100)

> **DRAFT FOR OWNER REVIEW.** These entries were drafted with AI assistance from the project facts. Alejandra must review, correct and validate every entry before submission, and replace each `TODO-verify` with the real, confirmed data (especially interview counts and findings). Do not submit invented evidence.

---

## Entry 1 — August 2026: Regulatory route and unit economics

- **Goal:** Decide whether Puente can legally hold and move customers' money, and whether the numbers can work.
- **What I did:** Mapped the three regulatory questions — (1) holds customer money? yes, USDC 1:1 in segregated reserves; (2) lends it? no; (3) pays yield? no. Concluded the right legal figure is an IFPE under the Fintech Law, entering first through a licensed partner while pursuing an own license.
- **Numbers set (all assumptions):** 1 USD = 20.00 MXN; spreads 1.5% remittances / 0.5% gig payroll; ARPU MXN 85; gross margin 70%; churn 8%; CAC MXN 150 → LTV ≈ MXN 744, LTV/CAC ≈ 5.0x, payback ≈ 2.5 months.
- **Open items:** Confirm license capital (~MXN 5M–14M) and authorization time (12–18 months) with official sources — `TODO-verify`.
- **AI use:** AI helped structure the regulatory questions and calculate the unit economics; I reviewed the logic. — `TODO-verify` (owner to confirm).

---

## Entry 2 — September 2026: Validation and interviews

- **Goal:** Check that the problem (6%–8% lost, 2–4 days waiting) is real for drivers and couriers.
- **What I did:** Interviews with DiDi drivers and Rappi couriers in southern CDMX. Number of interviews: `TODO-verify (enter exact number)`. Key quantified finding: `TODO-verify (e.g., "X of N reported losing Y% and waiting Z days")`.
- **Channel test:** Evaluated WhatsApp driver groups as the first acquisition channel. Visits → sign-ups → active users measured so far: `TODO-verify (enter real figures, or state "not measured, assumption")`.
- **Decision:** Keep the user (Mariana Torres archetype) and the core problem as defined, subject to what the interviews actually showed.
- **AI use:** AI drafted the interview guide and summary structure; findings are mine. — `TODO-verify`.

---

## Entry 3 — October 22, 2026: Scope frozen (Avance 2)

- **Goal:** Freeze the MVP scope to finish on time.
- **Decision:** Core flow fixed to 5 steps: secure sign-in → receive US remittance (USDC) → gig pay advance → use funds (QR or SPEI) → instant 1:1 balance and private history.
- **Out of scope confirmed:** no physical card, no staking/yield, no credit/loans, no real integrations (all rails simulated).
- **Technical choices:** Next.js + Prisma/SQLite, `bcryptjs`, `jose`, `zod`; per-user isolation via signed session cookie.
- **AI use:** AI generated scaffolding code; I defined the scope and reviewed the flow. — `TODO-verify`.

---

## Entry 4 — November 16, 2026: MVP closed, financial model and pitch

- **Goal:** Deliver the final project (app, repo docs, Excel model, 11-slide pitch + appendix, 7-minute script).
- **Done:** Working app with 2 fictional test accounts (Mariana Torres, Carlos Mendoza) demonstrating data isolation; repo files (README, SPEC, DECISIONS, AGENTS, BITACORA, PROJECT_METHOD); financial model in MXN with P&L, Cash, Unit economics and Valuation; pitch aligned to the Excel.
- **Checks to complete before submitting:** run seed and the full 5-step flow; verify every `TODO-verify` item; confirm every deck number matches the Excel; confirm no secrets in the repo.
- **Known gap:** ARPU (MXN 85) vs. blended spread × volume (≈ MXN 106) must be reconciled and documented — `TODO-verify`.
- **AI use:** AI generated code, documents and model drafts; I reviewed and validated all of it as owner of this log. — `TODO-verify`.
