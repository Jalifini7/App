import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { formatMxn, formatUsdc } from "@/lib/money";
import ActionPanel from "@/components/ActionPanel";
import LogoutButton from "@/components/LogoutButton";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  // Isolation: every query below is scoped by the session user id. No ids in URLs.
  const userId = await getSessionUserId();
  if (!userId) redirect("/login");

  const user = await prisma.user.findUnique({ where: { id: userId }, select: { name: true } });
  if (!user) redirect("/login");

  const [balance, incoming, outgoing, merchants] = await Promise.all([
    prisma.balance.findUnique({ where: { userId } }),
    prisma.incomingTransaction.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50 }),
    prisma.outgoingTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 50,
      include: { merchant: { select: { name: true } } },
    }),
    prisma.affiliatedMerchant.findMany({ where: { active: true }, select: { id: true, name: true, qrCode: true } }),
  ]);

  type Row = { id: string; at: Date; label: string; rail: string; amount: string; detail: string; positive: boolean };
  const rows: Row[] = [
    ...incoming.map((t) => ({
      id: t.id,
      at: t.createdAt,
      label: t.kind === "REMITTANCE" ? `Remittance from ${t.counterparty}` : `${t.counterparty} payout advance`,
      rail: t.rail,
      amount: `+${formatUsdc(t.netUsdcCents)}`,
      detail: `Gross ${formatUsdc(t.grossUsdcCents)} − spread ${(t.spreadBps / 100).toFixed(1)}% (${formatUsdc(t.feeUsdcCents)})`,
      positive: true,
    })),
    ...outgoing.map((t) => ({
      id: t.id,
      at: t.createdAt,
      label: t.kind === "QR_MERCHANT" ? `Paid ${t.merchant?.name ?? "merchant"}` : `SPEI withdrawal to ${t.destinationMasked}`,
      rail: t.rail,
      amount: `−${formatUsdc(t.usdcCents)}`,
      detail: `≈ ${formatMxn(t.mxnCents)} at 1 USD = 20.00 MXN`,
      positive: false,
    })),
  ].sort((a, b) => b.at.getTime() - a.at.getTime());

  return (
    <main className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-puente-700">Puente</h1>
          <p className="text-sm text-slate-600">Signed in as {user.name}</p>
        </div>
        <LogoutButton />
      </header>

      <section className="card">
        <p className="text-sm text-slate-600">5. USDC balance (1:1, updated instantly)</p>
        <p className="mt-1 text-4xl font-bold">{formatUsdc(balance?.usdcCents ?? 0)}</p>
        <p className="mt-1 text-xs text-slate-500">
          ≈ {formatMxn((balance?.usdcCents ?? 0) * 20)} · Custody on Solana USDC-SPL <span className="sim-tag">Simulated</span>
        </p>
      </section>

      <ActionPanel merchants={merchants} />

      <section className="card">
        <h2 className="mb-3 font-semibold">5. Your private transaction history</h2>
        {rows.length === 0 ? (
          <p className="text-sm text-slate-500">No transactions yet. Try a remittance above.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {rows.map((r) => (
              <li key={r.id} className="flex items-start justify-between gap-3 py-3">
                <div>
                  <p className="text-sm font-medium">{r.label}</p>
                  <p className="text-xs text-slate-500">{r.detail}</p>
                  <p className="text-[11px] text-slate-400">{r.rail} · {r.at.toISOString().slice(0, 16).replace("T", " ")} UTC</p>
                </div>
                <p className={`whitespace-nowrap text-sm font-semibold ${r.positive ? "text-emerald-700" : "text-slate-700"}`}>{r.amount}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
