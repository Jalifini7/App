import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { usdcToMxnCents } from "@/lib/money";
import { RAIL_LABELS } from "@/lib/rails";

// Step 4a: pay an affiliated merchant by QR (simulated). Atomic debit prevents overdrafts.
const schema = z.object({
  qrCode: z.string().min(1).max(40),
  amountUsdc: z.number().min(0.01).max(2000),
});

class InsufficientFunds extends Error {}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const merchant = await prisma.affiliatedMerchant.findFirst({
    where: { qrCode: parsed.data.qrCode, active: true },
  });
  if (!merchant) return NextResponse.json({ error: "Unknown merchant QR" }, { status: 404 });

  const usdcCents = Math.round(parsed.data.amountUsdc * 100);

  try {
    const balance = await prisma.$transaction(async (tx) => {
      const res = await tx.balance.updateMany({
        where: { userId, usdcCents: { gte: usdcCents } },
        data: { usdcCents: { decrement: usdcCents } },
      });
      if (res.count === 0) throw new InsufficientFunds();
      await tx.outgoingTransaction.create({
        data: {
          userId,
          kind: "QR_MERCHANT",
          usdcCents,
          mxnCents: usdcToMxnCents(usdcCents),
          merchantId: merchant.id,
          rail: `${RAIL_LABELS.qr} / ${RAIL_LABELS.solana}`,
        },
      });
      return tx.balance.findUniqueOrThrow({ where: { userId } });
    });
    return NextResponse.json({ ok: true, balanceUsdcCents: balance.usdcCents });
  } catch (e) {
    if (e instanceof InsufficientFunds) {
      return NextResponse.json({ error: "Insufficient balance" }, { status: 409 });
    }
    return NextResponse.json({ error: "Could not complete payment" }, { status: 500 });
  }
}
