import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { isValidClabe, maskClabe, usdcToMxnCents } from "@/lib/money";
import { RAIL_LABELS } from "@/lib/rails";

// Step 4b: withdraw MXN to a bank account via SPEI (simulated). Only the masked CLABE is stored.
const schema = z.object({
  clabe: z.string().regex(/^\d{18}$/),
  amountUsdc: z.number().min(0.01).max(2000),
});

class InsufficientFunds extends Error {}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success || !isValidClabe(parsed.data.clabe)) {
    return NextResponse.json({ error: "Invalid CLABE (18 digits with valid check digit)" }, { status: 400 });
  }

  const usdcCents = Math.round(parsed.data.amountUsdc * 100);
  const mxnCents = usdcToMxnCents(usdcCents);

  try {
    const balance = await prisma.$transaction(async (tx) => {
      const res = await tx.balance.updateMany({
        where: { userId, usdcCents: { gte: usdcCents } },
        data: { usdcCents: { decrement: usdcCents } },
      });
      if (res.count === 0) throw new InsufficientFunds();
      await tx.outgoingTransaction.create({
        data: {
          userId,
          kind: "SPEI_WITHDRAWAL",
          usdcCents,
          mxnCents,
          destinationMasked: maskClabe(parsed.data.clabe),
          rail: `${RAIL_LABELS.spei} / ${RAIL_LABELS.solana}`,
        },
      });
      return tx.balance.findUniqueOrThrow({ where: { userId } });
    });
    return NextResponse.json({ ok: true, mxnCents, balanceUsdcCents: balance.usdcCents });
  } catch (e) {
    if (e instanceof InsufficientFunds) {
      return NextResponse.json({ error: "Insufficient balance" }, { status: 409 });
    }
    return NextResponse.json({ error: "Could not complete withdrawal" }, { status: 500 });
  }
}
