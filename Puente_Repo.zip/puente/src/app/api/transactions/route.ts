import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";

// Step 5: private history. Scoped ONLY by the session user id; query params like ?userId= are ignored.
export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [balance, incoming, outgoing] = await Promise.all([
    prisma.balance.findUnique({ where: { userId } }),
    prisma.incomingTransaction.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50 }),
    prisma.outgoingTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 50,
      include: { merchant: { select: { name: true } } },
    }),
  ]);

  return NextResponse.json({ balanceUsdcCents: balance?.usdcCents ?? 0, incoming, outgoing });
}
