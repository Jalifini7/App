import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { FX_MXN_PER_USD, quoteRemittance } from "@/lib/money";
import { RAIL_LABELS } from "@/lib/rails";

// Step 2: remittance from the US. The user id comes ONLY from the session; any userId in the body is ignored.
const schema = z.object({
  amountUsd: z.number().min(1).max(2000), // demo limit (assumption)
  sender: z.string().trim().min(1).max(60).default("Family member (US)"),
});

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid amount (1 - 2,000 USD)" }, { status: 400 });

  const usdCents = Math.round(parsed.data.amountUsd * 100);
  const q = quoteRemittance(usdCents);

  const [tx, balance] = await prisma.$transaction([
    prisma.incomingTransaction.create({
      data: {
        userId,
        kind: "REMITTANCE",
        counterparty: parsed.data.sender,
        sourceCurrency: "USD",
        sourceAmountMinor: usdCents,
        fxRateMxnPerUsd: FX_MXN_PER_USD,
        grossUsdcCents: q.grossUsdcCents,
        spreadBps: q.spreadBps,
        feeUsdcCents: q.feeUsdcCents,
        netUsdcCents: q.netUsdcCents,
        rail: `${RAIL_LABELS.onRamp} / ${RAIL_LABELS.solana}`,
      },
    }),
    prisma.balance.update({
      where: { userId },
      data: { usdcCents: { increment: q.netUsdcCents } },
    }),
  ]);

  return NextResponse.json({ ok: true, netUsdcCents: tx.netUsdcCents, balanceUsdcCents: balance.usdcCents });
}
