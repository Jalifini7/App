import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { FX_MXN_PER_USD, quotePayroll } from "@/lib/money";
import { RAIL_LABELS } from "@/lib/rails";

// Step 3: gig payroll advance (DiDi / Rappi weekly payout) with a 0.5% spread.
const schema = z.object({
  platform: z.enum(["DiDi", "Rappi"]),
  amountMxn: z.number().min(100).max(20000), // demo limit (assumption)
});

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid amount (MXN 100 - 20,000)" }, { status: 400 });

  const mxnCents = Math.round(parsed.data.amountMxn * 100);
  const q = quotePayroll(mxnCents);

  const [tx, balance] = await prisma.$transaction([
    prisma.incomingTransaction.create({
      data: {
        userId,
        kind: "GIG_PAYROLL",
        counterparty: parsed.data.platform,
        sourceCurrency: "MXN",
        sourceAmountMinor: mxnCents,
        fxRateMxnPerUsd: FX_MXN_PER_USD,
        grossUsdcCents: q.grossUsdcCents,
        spreadBps: q.spreadBps,
        feeUsdcCents: q.feeUsdcCents,
        netUsdcCents: q.netUsdcCents,
        rail: `${RAIL_LABELS.gigPayroll} / ${RAIL_LABELS.solana}`,
      },
    }),
    prisma.balance.update({
      where: { userId },
      data: { usdcCents: { increment: q.netUsdcCents } },
    }),
  ]);

  return NextResponse.json({ ok: true, netUsdcCents: tx.netUsdcCents, balanceUsdcCents: balance.usdcCents });
}
