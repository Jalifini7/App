"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    setLoading(false);
    if (res.ok) {
      router.replace("/dashboard");
      router.refresh();
    } else {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Could not sign in");
    }
  }

  return (
    <main className="mx-auto mt-10 max-w-sm">
      <h1 className="text-3xl font-bold text-puente-700">Puente</h1>
      <p className="mt-1 text-sm text-slate-600">
        Instant USDC remittances and gig-pay advances. Simulated MVP.
      </p>

      <form onSubmit={onSubmit} className="card mt-6 space-y-4">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <ShieldCheck size={18} /> Secure sign-in
        </h2>
        <div>
          <label htmlFor="email" className="mb-1 block text-sm font-medium">Email</label>
          <input id="email" type="email" required autoComplete="username" className="input"
            value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label htmlFor="password" className="mb-1 block text-sm font-medium">Password</label>
          <input id="password" type="password" required autoComplete="current-password" className="input"
            value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        {error && <p className="text-sm text-red-600" role="alert">{error}</p>}
        <button className="btn w-full" disabled={loading}>{loading ? "Signing in..." : "Sign in"}</button>
        <p className="text-xs text-slate-500">
          Identity check: KYC <span className="sim-tag">Simulated</span> — no real documents are collected.
        </p>
      </form>
    </main>
  );
}
