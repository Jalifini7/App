import type { Metadata } from "next";
import "./globals.css";
import SimBanner from "@/components/SimBanner";

export const metadata: Metadata = {
  title: "Puente - Simulated Environment",
  description: "Instant USDC remittances and gig-pay advances for platform workers in Mexico City (simulated MVP).",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <SimBanner />
        <div className="mx-auto max-w-4xl px-4 pb-16 pt-16">{children}</div>
      </body>
    </html>
  );
}
