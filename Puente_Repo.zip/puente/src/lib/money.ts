// Pure money math. All amounts are integers in minor units (cents / centavos).
// Declared assumption: fixed FX rate 1 USD = 20.00 MXN, 1 USD = 1 USDC.

export const FX_MXN_PER_USD = 20;
export const SPREAD_BPS_REMITTANCE = 150; // 1.5%
export const SPREAD_BPS_PAYROLL = 50; // 0.5%

export type Quote = {
  grossUsdcCents: number;
  spreadBps: number;
  feeUsdcCents: number;
  netUsdcCents: number;
};

function applySpread(grossUsdcCents: number, spreadBps: number): Quote {
  const feeUsdcCents = Math.round((grossUsdcCents * spreadBps) / 10_000);
  return {
    grossUsdcCents,
    spreadBps,
    feeUsdcCents,
    netUsdcCents: grossUsdcCents - feeUsdcCents,
  };
}

/** Step 2: US remittance. Sender pays USD; 1 USD = 1 USDC; 1.5% spread. */
export function quoteRemittance(usdCents: number): Quote {
  return applySpread(usdCents, SPREAD_BPS_REMITTANCE);
}

/** Step 3: gig payroll advance. Platform pays MXN; converted at fixed FX; 0.5% spread. */
export function quotePayroll(mxnCents: number): Quote {
  const grossUsdcCents = Math.round(mxnCents / FX_MXN_PER_USD);
  return applySpread(grossUsdcCents, SPREAD_BPS_PAYROLL);
}

/** Step 4b: USDC -> MXN for SPEI withdrawal (1:1 USDC/USD at fixed FX, no extra spread). */
export function usdcToMxnCents(usdcCents: number): number {
  return Math.round(usdcCents * FX_MXN_PER_USD);
}

export function formatUsdc(cents: number): string {
  return `${(cents / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDC`;
}

export function formatMxn(cents: number): string {
  return `MXN ${(cents / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/** Validates a Mexican CLABE (18 digits + weighted check digit). */
export function isValidClabe(clabe: string): boolean {
  if (!/^\d{18}$/.test(clabe)) return false;
  const weights = [3, 7, 1];
  let sum = 0;
  for (let i = 0; i < 17; i++) sum += (parseInt(clabe[i], 10) * weights[i % 3]) % 10;
  const control = (10 - (sum % 10)) % 10;
  return control === parseInt(clabe[17], 10);
}

export function maskClabe(clabe: string): string {
  return `CLABE ****${clabe.slice(-4)}`;
}
