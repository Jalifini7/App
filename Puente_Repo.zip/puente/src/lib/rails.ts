// Labels for every external rail. ALL of them are SIMULATED in this MVP.
export const RAIL_LABELS = {
  onRamp: "On-Ramp USD->USDC (Simulated)",
  solana: "Solana USDC-SPL (Simulated)",
  gigPayroll: "Gig-Payroll (Simulated)",
  kyc: "KYC (Simulated)",
  qr: "Merchant QR (Simulated)",
  spei: "SPEI Withdrawal (Simulated)",
} as const;

export const SIM_BANNER_TEXT =
  "SIMULATED ENVIRONMENT / TESTNET — Fictional data, no real money";
