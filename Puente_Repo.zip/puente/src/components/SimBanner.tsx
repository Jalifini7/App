import { TriangleAlert } from "lucide-react";
import { SIM_BANNER_TEXT } from "@/lib/rails";

// Permanent, always-visible banner (fixed to the top of every screen).
export default function SimBanner() {
  return (
    <div
      role="alert"
      className="fixed inset-x-0 top-0 z-50 flex items-center justify-center gap-2 bg-amber-400 px-3 py-2 text-center text-xs font-bold text-slate-900 sm:text-sm"
    >
      <TriangleAlert size={16} aria-hidden />
      <span>{SIM_BANNER_TEXT}</span>
    </div>
  );
}
