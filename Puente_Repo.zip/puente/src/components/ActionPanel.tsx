"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowDownToLine, Banknote, QrCode, Landmark } from "lucide-react";

type Merchant = { id: string; name: string; qrCode: string };

const SIM = <span className="sim-tag">Simulated</span>;

export default function ActionPanel({ merchants }: { merchants: Merchant[] }) {
  const router = useRouter();
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  // Step 2 state
  const [usd, setUsd] = useState("200");
  // Step 3 state
  const [platform, setPlatform] = useState<"DiDi" | "Rappi">("DiDi");
  const [mxn, setMxn] = useState("1800");
  // Step 4 state
  const [qrCode, setQrCode] = useState(merchants[0]?.qrCode ?? "");
  const [qrAmount, setQrAmount] = useState("10");
  const [clabe, setClabe] = useState("");
  const [speiAmount, setSpeiAmount] = useState("50");

  async function call(url: string, body: unknown, okText: string) {
    setBusy(true);
    setMsg(null);
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) {
      setMsg({ type: "ok", text: okText });
      router.refresh(); // Step 5: balance and history update immediately
    } else {
      setMsg({ type: "err", text: data.error ?? "Something went wrong" });
    }
  }

  return (
    <div className="space-y-4">
      {msg && (
        <p role="status" className={`rounded-lg px-3 py-2 text-sm ${msg.type === "ok" ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-700"}`}>
          {msg.text}
        </p>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {/* Step 2 */}
        <form className="card space-y-3" onSubmit={(e) => { e.preventDefault(); call("/api/remittance", { amountUsd: Number(usd) }, "Remittance received and converted to USDC."); }}>
          <h3 className="flex items-center gap-2 font-semibold"><ArrowDownToLine size={16} /> 2. Receive a US remittance</h3>
          <p className="text-xs text-slate-600">
            USD → USDC via On-Ramp {SIM} and Solana USDC-SPL {SIM}. Spread: 1.5%.
          </p>
          <label className="block text-sm">Amount sent (USD)
            <input className="input mt-1" type="number" min="1" max="2000" step="0.01" value={usd} onChange={(e) => setUsd(e.target.value)} />
          </label>
          <button className="btn w-full" disabled={busy}>Simulate incoming remittance</button>
        </form>

        {/* Step 3 */}
        <form className="card space-y-3" onSubmit={(e) => { e.preventDefault(); call("/api/payroll", { platform, amountMxn: Number(mxn) }, "Gig payout advanced to your wallet."); }}>
          <h3 className="flex items-center gap-2 font-semibold"><Banknote size={16} /> 3. Gig pay advance</h3>
          <p className="text-xs text-slate-600">
            Weekly payout from the platform via Gig-Payroll {SIM}. Spread: 0.5%.
          </p>
          <label className="block text-sm">Platform
            <select className="input mt-1" value={platform} onChange={(e) => setPlatform(e.target.value as "DiDi" | "Rappi")}>
              <option>DiDi</option>
              <option>Rappi</option>
            </select>
          </label>
          <label className="block text-sm">Payout (MXN)
            <input className="input mt-1" type="number" min="100" max="20000" step="0.01" value={mxn} onChange={(e) => setMxn(e.target.value)} />
          </label>
          <button className="btn w-full" disabled={busy}>Simulate weekly payout</button>
        </form>

        {/* Step 4a */}
        <form className="card space-y-3" onSubmit={(e) => { e.preventDefault(); call("/api/spend/qr", { qrCode, amountUsdc: Number(qrAmount) }, "Merchant paid."); }}>
          <h3 className="flex items-center gap-2 font-semibold"><QrCode size={16} /> 4a. Pay a merchant by QR</h3>
          <p className="text-xs text-slate-600">Merchant QR {SIM}. Debits your USDC balance 1:1.</p>
          <label className="block text-sm">Scan QR (select merchant)
            <select className="input mt-1" value={qrCode} onChange={(e) => setQrCode(e.target.value)}>
              {merchants.map((m) => <option key={m.id} value={m.qrCode}>{m.name} · {m.qrCode}</option>)}
            </select>
          </label>
          <label className="block text-sm">Amount (USDC)
            <input className="input mt-1" type="number" min="0.01" step="0.01" value={qrAmount} onChange={(e) => setQrAmount(e.target.value)} />
          </label>
          <button className="btn w-full" disabled={busy}>Pay merchant</button>
        </form>

        {/* Step 4b */}
        <form className="card space-y-3" onSubmit={(e) => { e.preventDefault(); call("/api/spend/spei", { clabe, amountUsdc: Number(speiAmount) }, "SPEI withdrawal sent."); }}>
          <h3 className="flex items-center gap-2 font-semibold"><Landmark size={16} /> 4b. Withdraw MXN via SPEI</h3>
          <p className="text-xs text-slate-600">SPEI Withdrawal {SIM}. Converted at 1 USD = 20.00 MXN.</p>
          <label className="block text-sm">CLABE (18 digits)
            <input className="input mt-1" inputMode="numeric" maxLength={18} value={clabe} onChange={(e) => setClabe(e.target.value.replace(/\D/g, ""))} placeholder="Test CLABE: 012180001234567899" />
          </label>
          <label className="block text-sm">Amount (USDC)
            <input className="input mt-1" type="number" min="0.01" step="0.01" value={speiAmount} onChange={(e) => setSpeiAmount(e.target.value)} />
          </label>
          <button className="btn w-full" disabled={busy}>Withdraw to bank</button>
        </form>
      </div>
    </div>
  );
}
